/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package csv.trab;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author pauloatavila
 */
public class ArmazenarBD {
    static void salvar(File file) {
        String url = "jdbc:postgresql://localhost:5432/csvtrab";
           String sql = "INSERT INTO principal(campus, cod_curso, curso, matricula, nome, versao_curso, forma_ingr, ano_ingr, periodo_ingr, "
                   + "form_evasao, ano_evasao, periodo_evasao,"
                   + "email_um, email_dois, fone_res, fone_cel, fone_com, "
                   + "dt_ingr, dt_conclusao, dt_colacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, "
                   + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try{
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line = "";
            try (Connection con = DriverManager.getConnection(url, "db20152", "paulo22atavila");
            PreparedStatement stm = con.prepareStatement(sql)){
            
                while ((line = br.readLine()) != null) {
                    // "," ou ";" de acordo com o arquivo
                    String[] row = line.split(",");
                    stm.setString(1, row[0]);
                    stm.setString(2, row[1]);
                    stm.setString(3, row[2]);
                    stm.setString(4, row[3]);
                    stm.setString(5, row[4]);
                    stm.setString(6, row[5]);
                    stm.setString(7, row[6]);
                    stm.setString(8, row[7]);
                    stm.setString(9, row[8]);
                    stm.setString(18, row[9]);
                    stm.setString(10, row[10]);
                    stm.setString(11, row[11]);
                    stm.setString(12, row[12]);
                    stm.setString(19, row[13]);
                    stm.setString(20, row[14]);
                    stm.setString(13, row[15]);
                    stm.setString(14, row[16]);
                    stm.setString(15, row[17]);
                    stm.setString(16, row[18]);
                    stm.setString(17, row[19]);

                    stm.addBatch();
                    stm.executeBatch();
        
                }
                
            } catch (SQLException ex) {
            
                System.err.println("Falha na conexão "+ ex.getSQLState() + ex.getMessage());
                System.out.println(ex.getNextException());
            
            }
        }catch(Exception x){
            System.out.println(x.getMessage() + " erro");
            System.out.println(x.getLocalizedMessage());
        }
    }
}
