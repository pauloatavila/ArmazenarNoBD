
package csv.trab;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class MostraBD extends javax.swing.JFrame {

    /**
     * Creates new form MostraBD
     */
    public MostraBD() {
        initComponents();
        gerarTabela();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabela = new javax.swing.JTable();
        sairBtt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tabela.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabela);

        sairBtt.setIcon(new javax.swing.ImageIcon(getClass().getResource("/csv/trab/sair_318-72557.jpg"))); // NOI18N
        sairBtt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairBttActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(sairBtt)
                .addContainerGap())
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 688, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sairBtt)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void sairBttActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairBttActionPerformed
        dispose();
    }//GEN-LAST:event_sairBttActionPerformed

    private void gerarTabela(){
        
        System.out.println("skmc");
        String url = "jdbc:postgresql://localhost:5432/csvtrab";
        String sql = "SELECT campus, cod_curso, curso, matricula, nome, versao_curso, forma_ingr, ano_ingr, periodo_ingr, "
                   + "form_evasao, ano_evasao, periodo_evasao,"
                   + "email_um, email_dois, fone_res, fone_cel, fone_com, "
                   + "dt_ingr, dt_conclusao, dt_colacao, id FROM principal";
        
        DefaultTableModel modelo = new javax.swing.table.DefaultTableModel();
        modelo.addColumn("CAMPUS");
        modelo.addColumn("COD_CURSO");
        modelo.addColumn("CURSO");
        modelo.addColumn("MATRICULA");
        modelo.addColumn("NOME");
        modelo.addColumn("VERSAO_CURSO");
        modelo.addColumn("FORMAINGRESSO");
        modelo.addColumn("ANO_INGRESSO");
        modelo.addColumn("PERIODO_INGRESSO");
        modelo.addColumn("DT_INGRESSO");
        modelo.addColumn("FORMA_DE_EVASAO");
        modelo.addColumn("ANO_DE_EVASAO");
        modelo.addColumn("PERIODO_DE_EVASAO");
        modelo.addColumn("DT_CONCLUSAO");
        modelo.addColumn("DT_COLACAO_GRAU");
        modelo.addColumn("EMAIL");
        modelo.addColumn("EMAIL_1");
        modelo.addColumn("FONE_RESIDENCIAL");
        modelo.addColumn("FONE_CELULAR");
        modelo.addColumn("FONE_COMERCIAL");
        

     
        try(Connection con1 = DriverManager.getConnection(url, "db20152", "paulo22atavila");
        PreparedStatement stm1 = con1.prepareStatement(sql); ResultSet rs = stm1.executeQuery()){
            
            while(rs.next()){
                modelo.addRow(new String[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), 
                rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11), rs.getString(12), rs.getString(13), 
                rs.getString(14), rs.getString(15), rs.getString(16), rs.getString(17), rs.getString(19), rs.getString(19), rs.getString(20) });
            }
            tabela.setModel(modelo);
        }catch(SQLException x){
            
        }
        
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton sairBtt;
    private javax.swing.JTable tabela;
    // End of variables declaration//GEN-END:variables
}
