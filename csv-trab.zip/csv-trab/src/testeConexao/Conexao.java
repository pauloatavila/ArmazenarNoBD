/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testeConexao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexao {

    public static void main(String[] args) {
    
           String url = "jdbc:postgresql://localhost:5432/csv";
           String sql = "INSERT INTO principal(campus, cod_curso, curso, matricula, nome, versao_curso, forma_ingresso, periodo_ingresso, "
                   + "forma_evasao, ano_evasao, periodo_evasao,"
                   + "email_um, email_dois, fone_residencial, fone_celular, fone_comercial, "
                   + "ano_ingresso, dt_ingresso, dt_conclusao, dt_colacao) VALUES (?, ?, ?, ?, ?, ?, ?, ?, "
                   + "?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
           
        String sValue;
        java.sql.Date dtValue;
        try (Connection con = DriverManager.getConnection(url, "postgres", "123456");
            PreparedStatement stm = con.prepareStatement(sql)){
            
                stm.setString(1, "Palmas");
                stm.setString(2, "5451");
                stm.setString(3, "CC");
                stm.setString(4, "625146");
                stm.setString(5, "Pedro Henrique");
                stm.setString(6, "2121");
                stm.setString(7, "vestibular");
                stm.setString(8, "1 semestre");  
                stm.setString(18, "12/05/2012");
                stm.setString(9, "Formado");
                stm.setString(10, "2012");
                stm.setString(11, "2 semestre");
                stm.setString(19, "12/05/2012");
                stm.setString(20, "12/05/2012");
                stm.setString(14, "xxxx");
                stm.setString(12, "kleysonb@hotmail.com");
                stm.setString(16, "xxxx");
                stm.setString(13, "yyyy");
                stm.setString(15, "656156155");
                stm.setString(17, "2012");


                stm.addBatch();
                stm.executeBatch();
            
            
        } catch (SQLException ex) {
            
            System.err.println("Falha na conexão "+ ex.getSQLState() + ex.getMessage());
            System.out.println(ex.getNextException());
            
        }
    }
    
}

